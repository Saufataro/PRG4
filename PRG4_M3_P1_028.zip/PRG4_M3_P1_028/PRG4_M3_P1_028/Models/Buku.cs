﻿using System.ComponentModel.DataAnnotations;

namespace PRG4_M3_P1_028.Models
{
    public class Buku
    {
        public int id { get; set; }
        [Required(ErrorMessage = "Judul Wajib Diisi.")]
        [MaxLength(30, ErrorMessage ="Judul Maksimal 30 Karakter")]
        public string judul { get; set; }
        [Required(ErrorMessage = "Penulis Wajib Diisi.")]
        [MaxLength(30, ErrorMessage = "Penulis Maksimal 30 Karakter.")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Penulis Hanya Boleh Huruf.")]
        public string penulis { get; set; }
        [Required(ErrorMessage = "Penerbit Wajib Diisi.")]
        public string penerbit { get; set; }
        [Required(ErrorMessage = "IISN Wajib Diisi.")]
        [RegularExpression("^[0-9]{4}-[0-9]{4}$", ErrorMessage = "Format ISSN Tidak Valid. Gunakan Format XXXX-XXXX")]
        public string issn { get; set; }
        [Range(0,int.MaxValue, ErrorMessage ="Tahun Tidak Valid.")]
        [RegularExpression("^(19|20)\\d{2}$", ErrorMessage ="Tahun Tidak Valid.")]
        public int tahun { get; set; }
        [Range(0,1, ErrorMessage ="Status Tidak Valid.")]
        public int status { get; set; }
    }
}
